# Pools > 31.05.26-19:29am
https://universe.roboflow.com/jans-workspace-l9aj6/pools-tduhd

Provided by a Roboflow user
License: CC BY 4.0

